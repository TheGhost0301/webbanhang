=== Greenshift Animation Addon ===
Contributors: wpsoul
Tags: gutenberg, block, page-builder, animation, gsap, gutenberg addons
Author: Wpsoul
Author URI: https://wpsoul.com
Requires at least: 5.9
Tested up to: 6.1
Requires PHP: 7.0
Stable tag: 1.8.3

Add additional quality animation blocks to your site.
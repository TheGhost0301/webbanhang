<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="rh-mini-sidebar floatleft tabletblockdisplay">
    <?php dynamic_sidebar( 'bprh-group-sidebar' ); ?>        			
</div>
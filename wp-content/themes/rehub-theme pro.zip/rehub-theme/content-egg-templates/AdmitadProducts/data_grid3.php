<?php
/*
  Name: Grid of products (3 column)
 */
?>
<?php $columnsgrid = 3;?>
<?php include(rh_locate_template('inc/ce_common/data_grid.php')); ?>
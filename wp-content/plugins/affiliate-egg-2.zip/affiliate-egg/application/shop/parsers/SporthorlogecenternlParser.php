<?php

namespace Keywordrush\AffiliateEgg;

/**
 * SporthorlogecenternlParser class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2017 keywordrush.com
 */
require_once dirname(__FILE__) . '/CoolbluenlParser.php';

class SporthorlogecenternlParser extends CoolbluenlParser {
    
}

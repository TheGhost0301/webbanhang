<?php

namespace Keywordrush\AffiliateEgg;

/**
 * RuiherbcomParser class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2014 keywordrush.com
 */
class RuiherbcomParser extends MicrodataShopParser {

    protected $charset = 'utf-8';
    protected $currency = 'USD';

    public function parseCatalog($max)
    {
        $urls = array_slice($this->xpathArray(".//*[contains(@class, 'product-inner')]/a[1]/@href"), 0, $max);
        if (!$urls)
            $urls = array_slice($this->xpathArray(".//div[@class='panel']//a[@class='image-link']/@href"), 0, $max);
        if (!$urls)
            $urls = array_slice($this->xpathArray(".//div[@id='display-results-content']//a[@class='image-link']/@href"), 0, $max);
        if (!$urls)
            $urls = array_slice($this->xpathArray(".//div[@class='panel']/article/a[@class='image-link']/@href"), 0, $max);
        if (!$urls)
            $urls = array_slice($this->xpathArray(".//div[@class='panel']//bdi//a[@class='product-image']/@href"), 0, $max);
        if (!$urls)
            $urls = array_slice($this->xpathArray(".//*[@class='absolute-link-wrapper']/a/@href"), 0, $max);
        return $urls;
    }

    public function parseTitle()
    {
        if ($r = parent::parseTitle())
            return $r;
        $res = $this->xpathScalar(".//*[contains(@class, 'prod-title')]");
        $mnf = $this->parseManufacturer();
        $res = trim(str_replace($mnf, "", $res), ", ");
        return $res;
    }

    public function parsePrice()
    {
        if ($r = parent::parsePrice())
            return $r;

        $price = $this->xpathScalar(".//meta[@property='og:price:amount']/@content");
        if (!$price)
        // reviews page
            $price = $this->xpathScalar(".//*[@class='pricesWraper']/p[@class='prod-price']");
        return $price;
    }

    public function parseOldPrice()
    {

        $price = $this->xpathScalar(".//meta[@property='og:standard_price']/@content");
        if ($price < $this->parsePrice())
            return $price;

        $price = $this->xpathScalar(".//*[@id='product-msrp']//s");
        return $price;
    }

    public function parseManufacturer()
    {
        return $this->xpathScalar(".//*[@id='brand']//strong");
    }

    public function parseImg()
    {
        $res = $this->xpathScalar(".//meta[@property='og:images']//@content");
        $res = str_replace("/b/", "/v/", $res);
        if ($res)
            return $res;

        // reviews page
        $img = $this->xpathScalar(".//div[contains(@class,'prod-image-holder')]//img/@src");

        if (!$img)
            $img = $this->xpathScalar(".//img[@id='iherb-product-image']/@src");
        return $img;
    }

    public function parseImgLarge()
    {
        return $this->xpathScalar(".//div[contains(@class,'prod-im-big')]//img/@src");
    }

    public function parseExtra()
    {
        $extra = parent::parseExtra();

        $extra['features'] = array();

        $results = $this->xpathArray(".//ul[@id='product-specs-list']/li[not(div)]");
        $feature = array();
        foreach ($results as $res)
        {
            $expl = explode(":", $res, 2);
            if (count($expl) == 2)
            {
                $feature['name'] = \sanitize_text_field($expl[0]);
                $feature['value'] = \sanitize_text_field($expl[1]);
                $extra['features'][] = $feature;
            }
        }

        $extra['images'] = array();
        $results = $this->xpathArray(".//div[@class='smImHolder']//img/@src");
        foreach ($results as $i => $res)
        {
            if ($i == 0)
                continue;
            $extra['images'][] = str_replace('/b/', '/l/', $res);
        }

        $extra['comments'] = array();
        $comments = $this->xpathArray(".//div[@class='recent-reviews' or @class='prodOverview-section']//bdi/p");
        $ratings = $this->xpathScalar(".//div[@class='recent-reviews' or @class='prodOverview-section']//*[@class='rating']//a/i[2]/@class");
        for ($i = 0; $i < count($comments); $i++)
        {
            $comment['comment'] = sanitize_text_field($comments[$i]);

            if (!empty($ratings[$i]))
            {
                preg_match('/icon-stars_(\d+)/', $ratings[$i], $matches);
                if ($matches)
                    $comment['rating'] = TextHelper::ratingPrepare($matches[1]);
            }
            $extra['comments'][] = $comment;
        }

        return $extra;
    }

    public function getCurrency()
    {
        if ($r = $this->xpathScalar(".//meta[@property='og:price:currency']/@content"))
            return $r;
        else
            return $this->currency;
    }

}

<?php

namespace Keywordrush\AffiliateEgg;

/**
 * EldoradocomuaParser class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2016 keywordrush.com
 */

require_once dirname(__FILE__) . '/EldoradouaParser.php';

class EldoradocomuaParser extends EldoradouaParser {


}

<?php

namespace Keywordrush\AffiliateEgg;

/**
 * FrendiruParser class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2016 keywordrush.com
 */
require_once dirname(__FILE__) . '/GrouponruParser.php';

class FrendiruParser extends GrouponruParser {
    
}
